package net.fullstack.api.controller.api.v1;

import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import net.fullstack.api.dto.BbsReplyDTO;
import net.fullstack.api.service.BbsReplyServiceIf;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.MediaType;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Log4j2
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/bbs/replies")
public class BbsReplyController {
    private final BbsReplyServiceIf bbsReplyService;

    @Tag(name="REGIST", description = "POST방식 댓글 등록")
    @PostMapping(value="/regists", consumes = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, Long> regists(
           @Valid @RequestBody BbsReplyDTO bbsReplyDTO,
           BindingResult bindingResult) throws BindException {
        log.info("받은 DTO: {}", bbsReplyDTO);
        if (bindingResult.hasErrors()) {
            throw new BindException(bindingResult);
        }
        Map<String, Long> map = new HashMap<>();
        long result = bbsReplyService.bbsReplyRegist(bbsReplyDTO);
        map.put("idx", result);
        return map;
    }

    @Tag(name="Bbs Reply List", description = "GET방식 특정 게시물의 댓글 목록 조회")
    @GetMapping(value="/lists/{bbsidx}")
    public List<BbsReplyDTO> bbsReplyList(@PathVariable("bbsIdx") Long bbs_idx) {
        Pageable pageable = PageRequest.of(0, 10, Sort.by("idx").descending());
        List<BbsReplyDTO> replyDTOList = bbsReplyService.bbsReplyList(bbs_idx, pageable);
        return replyDTOList;
    }
    @Tag(name="Bbs Reply View", description = "GET방식 특정 댓글 조회")
    @GetMapping("/{idx}")
    public BbsReplyDTO bbsReplyView(@PathVariable("idx") Long idx) {
        return bbsReplyService.bbsReplyView(idx);
    }
    @Tag(name="Bbs Reply Modify", description = "PUT방식의 특정 댓글 정보 수정")
    @PutMapping("/{idx}")
    public Map<String, Long> bbsReplyModify(@PathVariable("idx") Long idx,
                               @Valid @RequestBody BbsReplyDTO bbsReplyDTO) {
        bbsReplyService.bbsReplyModify(bbsReplyDTO);
        Map<String, Long> map = new HashMap<>();
        map.put("idx", idx);
        return map;
    }
    @Tag(name="Bbs Reply Delete", description = "DELETE 방식의 특정 댓글 삭제")
    @DeleteMapping("/{idx}")
    public Map<String, Long> bbsReplyDelete(@PathVariable("idx") Long idx) {
        Map<String, Long> map = new HashMap<>();
        bbsReplyService.bbsReplyDelete(idx);
        map.put("idx", idx);
        return map;
    }
}
