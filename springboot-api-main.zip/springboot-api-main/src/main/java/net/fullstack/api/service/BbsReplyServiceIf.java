package net.fullstack.api.service;

import net.fullstack.api.dto.BbsReplyDTO;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface BbsReplyServiceIf {
    long bbsReplyRegist(BbsReplyDTO bbsReplyDTO);

    List<BbsReplyDTO> bbsReplyList(Long bbs_idx, Pageable pageable);

    BbsReplyDTO bbsReplyView(Long idx);

    void bbsReplyModify(BbsReplyDTO bbsReplyDTO);

    void bbsReplyDelete(Long idx);
}