package net.fullstack.api.repository.bbs;

import net.fullstack.api.domain.BbsReplyEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface BbsReplyRepository extends JpaRepository<BbsReplyEntity, Long> {
    @Query("SELECT r FROM BbsReplyEntity r WHERE r.board.idx = :bbs_idx")
    Page<BbsReplyEntity> lists(@Param("bbs_idx") Long bbs_idx, Pageable pageable);
}
