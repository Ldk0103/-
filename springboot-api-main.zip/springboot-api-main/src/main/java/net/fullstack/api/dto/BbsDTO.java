package net.fullstack.api.dto;

import jakarta.persistence.*;
import lombok.*;
import net.fullstack.api.domain.BbsBaseEntity;

@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BbsDTO extends BbsBaseEntity {
    @Column(name="idx", unique=true, nullable = false)
    private long idx;
    private String user_id;
    private String title;
    private String content;
    private String display_date;
    private int read_cnt;
}
