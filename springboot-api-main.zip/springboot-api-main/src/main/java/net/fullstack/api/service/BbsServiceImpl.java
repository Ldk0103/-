package net.fullstack.api.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import net.fullstack.api.domain.BbsEntity;
import net.fullstack.api.dto.BbsDTO;
import net.fullstack.api.dto.PageRequestDTO;
import net.fullstack.api.dto.PageResponseDTO;
import net.fullstack.api.repository.BbsRepository;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

@Log4j2
@Service
@RequiredArgsConstructor
public class BbsServiceImpl implements BbsServiceIf {

    private final ModelMapper modelMapper;
    private final BbsRepository bbsRepository;

    @Override
    public long countAll() {
        return bbsRepository.countAll();
    }

    @Override
    public List<BbsDTO> findAll(int page_no, int page_size) {
        Pageable pageable = PageRequest.of(page_no, page_size, Sort.by("idx").descending());
        return bbsRepository.findAll(pageable).stream().map(bbsEntity -> modelMapper.map(bbsEntity, BbsDTO.class)).toList();
    }

    public Page<BbsDTO> findAll(PageRequestDTO pageRequestDTO) {
        Pageable pageable = PageRequest.of(pageRequestDTO.getPage_no(), pageRequestDTO.getPage_size(), Sort.by("idx").descending());
        Page<BbsEntity> result = bbsRepository.findAll(pageable);
        Page<BbsDTO> bbsDTOList = new PageImpl<>(result.getContent().stream().map(entity -> modelMapper.map(entity , BbsDTO.class)).collect(Collectors.toList()), result.getPageable(), result.getTotalElements());

        return bbsDTOList;
    }

    public PageResponseDTO<BbsDTO> findAllWithSearch(PageRequestDTO pageRequestDTO) {
        // 검색조건에 따른 페이지 객체
        // Pageable pageable = PageRequest.of(pageRequestDTO.getPage_no(), pageRequestDTO.getPage_size(), Sort.by("idx").descending());
        Pageable pageable = pageRequestDTO.getPageable("idx");

        String[] search_categories = pageRequestDTO.getSearch_categories();
        Page<BbsEntity> result = bbsRepository.search2(pageable, pageRequestDTO.getSearch_categories(), pageRequestDTO.getSearch_word());
        List<BbsEntity> entityList = result.getContent();
        List<BbsDTO> bbsDTOList = entityList.stream().map(
                entity-> modelMapper.map(entity, BbsDTO.class)
        ).collect(Collectors.toList());
        long totalCount = bbsRepository.countAll();
        PageResponseDTO<BbsDTO> responseDTO = PageResponseDTO.<BbsDTO>withAll()
                .reqDTO(pageRequestDTO)
                .dtoList(bbsDTOList)
                .total_count(totalCount)
                .build();
        return responseDTO;
    }

    @Override
    public BbsDTO findById(long id) {
        // 옵셔널
        return modelMapper.map(bbsRepository.findById(id).orElseThrow(() -> new NoSuchElementException("해당 ID 없음")), BbsDTO.class);
    }

    @Override
    public long save(BbsDTO dto) {
        BbsEntity bbsEntity = bbsRepository.save(modelMapper.map(dto, BbsEntity.class));
        return bbsEntity != null? bbsEntity.getIdx() : 0;
    }

    @Override
    public long update(BbsDTO dto) {
        return bbsRepository.save(modelMapper.map(dto, BbsEntity.class)).getIdx();
    }

    @Override
    public void deleteById(long id) {
        bbsRepository.deleteById(id);
    }
}
