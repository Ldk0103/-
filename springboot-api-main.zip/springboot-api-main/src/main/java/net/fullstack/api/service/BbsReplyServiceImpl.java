package net.fullstack.api.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import net.fullstack.api.domain.BbsEntity;
import net.fullstack.api.domain.BbsReplyEntity;
import net.fullstack.api.dto.BbsDTO;
import net.fullstack.api.dto.BbsReplyDTO;
import net.fullstack.api.repository.BbsRepository;
import net.fullstack.api.repository.bbs.BbsReplyRepository;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Log4j2
@Service
@Transactional
@RequiredArgsConstructor
public class BbsReplyServiceImpl implements BbsReplyServiceIf {
    private final ModelMapper modelMapper;
    private final BbsReplyRepository bbsReplyRepository;
    private final BbsRepository bbsRepository;

    @Override
    public long bbsReplyRegist(BbsReplyDTO bbsReplyDTO) {
        BbsReplyEntity bbsReplyEntity = modelMapper.map(bbsReplyDTO, BbsReplyEntity.class);
        bbsReplyEntity.setBoard(BbsEntity.builder().idx(bbsReplyDTO.getBoard_idx()).build());
        BbsReplyEntity savedResult = bbsReplyRepository.save(bbsReplyEntity);
        long rtnResult = savedResult.getIdx();
        return rtnResult;
    }

    @Override
    public List<BbsReplyDTO> bbsReplyList(Long bbs_idx, Pageable pageable) {
        Page<BbsReplyEntity> resultEntity = bbsReplyRepository.lists(bbs_idx, pageable);
        List<BbsReplyDTO> bbsReplyDTOList = resultEntity.getContent().stream().map(entity -> modelMapper.map(entity, BbsReplyDTO.class)).toList();
        return bbsReplyDTOList;
    }

    @Override
    public BbsReplyDTO bbsReplyView(Long idx) {
        Optional<BbsReplyEntity> result = bbsReplyRepository.findById(idx);
        BbsReplyEntity bbsReplyEntity = result.orElseThrow();
        BbsReplyDTO bbsReplyDTO = modelMapper.map(bbsReplyEntity, BbsReplyDTO.class);
        bbsReplyDTO.setBoard_idx(bbsReplyEntity.getBoard().getIdx());
        return bbsReplyDTO;
    }

    @Override
    public void bbsReplyModify(BbsReplyDTO bbsReplyDTO) {
        Optional<BbsReplyEntity> replyEntityOptional = bbsReplyRepository.findById(bbsReplyDTO.getIdx());
        if(replyEntityOptional.isPresent()) {
            BbsReplyEntity replyEntity = replyEntityOptional.get();
            replyEntity.setReply_title(bbsReplyDTO.getReply_title());
            replyEntity.setReply_content(bbsReplyDTO.getReply_content());
            replyEntity.setReply_modify_date(LocalDateTime.now());
            replyEntity.setBoard(BbsEntity.builder().idx(bbsReplyDTO.getBoard_idx()).build());
            bbsReplyRepository.save(replyEntity);
        }
    }

    @Override
    public void bbsReplyDelete(Long idx) {
        bbsReplyRepository.deleteById(idx);
    }
}