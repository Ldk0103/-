package net.fullstack.api.domain;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name="tbl_board")
public class BbsEntity extends BbsBaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="idx", unique=true, nullable = false)
    private long idx;

    @Column(length=20, nullable = false, columnDefinition = "VARCHAR(20) NOT NULL COMMENT '아이디' COLLATE 'utf8mb4_unicode_ci'")
    private String user_id;
    @Column(columnDefinition = "VARCHAR(200) NOT NULL COMMENT '글 제목' COLLATE 'utf8mb4_unicode_ci'")
    private String title;
    @Column(columnDefinition = "text NOT NULL COMMENT '글 내용' COLLATE 'utf8mb4_unicode_ci'")
    private String content;
    @Column(columnDefinition = "CHAR(10) NOT NULL COMMENT '출력 날짜' COLLATE 'utf8mb4_unicode_ci'")
    private String display_date;
    @Builder.Default
    @Min(0)
    @Column(columnDefinition = "INT NULL DEFAULT '0' COMMENT '조회수'")
    private int read_cnt=0;

    public void modify(Long idx, String user_id, String title, String content, String display_date) {
        this.idx = idx;
        this.user_id = user_id;
        this.title = title;
        this.content = content;
        this.display_date = display_date;
        super.setModify_date(LocalDateTime.now());
    }
}
