package net.fullstack.api.controller;

import lombok.extern.log4j.Log4j2;
import net.fullstack.api.dto.BbsDTO;
import net.fullstack.api.dto.PageRequestDTO;
import net.fullstack.api.service.BbsServiceIf;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@Log4j2
@Controller
@RequestMapping("/bbs")
public class BbsController {

    @Autowired
    private BbsServiceIf bbsService;

    @RequestMapping
    public String bbsList(
            @ModelAttribute PageRequestDTO pageRequestDTO,
            Model model) {
        pageRequestDTO.setPage_no(pageRequestDTO.getPage_no() < 1 ? 0 : pageRequestDTO.getPage_no() - 1);
        int page_size = pageRequestDTO.getPage_size();
//        List<BbsDTO> dtoList = bbsService.findAll(page_no, pageRequestDTO.getPage_size());
        Page<BbsDTO> bbsDTOPage = bbsService.findAll(pageRequestDTO);
        // long total_count = bbsService.countAll();
        model.addAttribute("pageRequestDTO", pageRequestDTO);
        model.addAttribute("page_size", pageRequestDTO.getPage_size());
        model.addAttribute("page_no", pageRequestDTO.getPage_no());
        model.addAttribute("bbsDTOPage", bbsDTOPage);
//        model.addAttribute("dtoList", dtoList);
        return "bbs/list";
    }
    @RequestMapping("/{idx}")
    public String getOne(@PathVariable long idx, Model model) {
        BbsDTO dto = bbsService.findById(idx);
        model.addAttribute("dto", dto);
        return "bbs/view";
    }
    @GetMapping("/write")
    public String bbsRegistGET(Model model) {
        return "bbs/write";
    }
    @PostMapping("/write")
    public String bbsRegistPost(
            @ModelAttribute BbsDTO bbsDTO,
            Model model) {
        bbsService.save(bbsDTO);
        return "redirect:/bbs";
    }
    @GetMapping("/{idx}/edit")
    public String bbsModifyGet(@PathVariable long idx, Model model) {
        BbsDTO bbsDTO = bbsService.findById(idx);
        model.addAttribute("dto", bbsDTO);
        return "bbs/modify";
    }
    @PostMapping("/{idx}/edit")
    public String bbsModifyPost(@PathVariable long idx,
                                @ModelAttribute BbsDTO dto, Model model) {
        bbsService.update(dto);
        return "redirect:/bbs";
    }
    @PostMapping("/{idx}/delete")
    @ResponseBody
    public Map<String, Object> bbsDelete(@PathVariable long idx,
                                         Model model) {
        bbsService.deleteById(idx);
        Map<String, Object> resp = new HashMap<>();
        resp.put("success", true);
        return resp;
    }

}
