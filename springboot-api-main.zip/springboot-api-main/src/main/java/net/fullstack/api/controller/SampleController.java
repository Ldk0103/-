package net.fullstack.api.controller;

import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Log4j2
@Controller
@RequestMapping("/sample")
public class SampleController {

    @GetMapping("/hello")
    public void hello(
            @RequestParam(name="msg", required = false, defaultValue = "Hello, world!") String msg,
            Model model
    ) {
        model.addAttribute("msg", msg);
    }

    @GetMapping("/ex1")
    public void ex1(Model model) {
        model.addAttribute("num11", "11");
        model.addAttribute("num22", "22");
        model.addAttribute("num33", "33");
    }
    @GetMapping("/ex2")
    public void ex2(Model model) {
        List<String> list = Arrays.asList("a", "b", "c", "d", "e", "f", "g");
        model.addAttribute("list", list);
    }
    @GetMapping("/ex3")
    public void ex3(Model model) {
        List<String> list = Arrays.asList("a", "b", "c", "d", "e", "f", "g");
        model.addAttribute("list", list);
    }

    @GetMapping("/ex4")
    public void ex4(
            Model model,
            @RequestParam(value = "msg", required = false) String[] msg
    ) {
        if(msg!=null) {
            for (String m : msg) {
                log.info(m);
            }
        }
    }

    class SampleDTO {
        private String p1, p2, p3;
        public String getP1() {return p1;}
        public String getP2() {return p2;}
        public String getP3() {return p3;}
    }

    @GetMapping("/ex5")
    public void ex5(Model model) {
        List<String> strList = IntStream.range(1, 10).mapToObj(i->"Data"+i).collect(Collectors.toList());
        model.addAttribute("list", strList);

        Map<String, String> map = new HashMap<>();
        map.put("A", "AAAA");
        map.put("B", "BBBB");
        model.addAttribute("map", map);

        SampleDTO sampleDTO = new SampleDTO();
        sampleDTO.p1="Value--p1";
        sampleDTO.p2="Value--p2";
        sampleDTO.p3="Value--p3";
        model.addAttribute("dto", sampleDTO);
    }

    @GetMapping("/ex6")
    public void ex6(Model model) {
        List<SampleMember> list = Arrays.asList(
                new SampleMember("홍길동1", 12),
                new SampleMember("홍길동2", 12),
                new SampleMember("홍길동3", 12),
                new SampleMember("홍길동4", 12),
                new SampleMember("홍길동4", 12)
        );
        model.addAttribute("list", list);
    }

    class SampleMember {
        SampleMember() {}
        SampleMember(String name, int age) {
            this.name = name;
            this.age = age;
        }

        public String name;
        public int age;

        public String getName() {
            return name;
        }
        public int getAge() {
            return age;
        }
        public void setName(String name) {
            this.name = name;
        }
        public void setAge(int age) {
            this.age = age;
        }
        @Override
        public String toString() {
            return "SampleMember [name="+name+", age="+age+"]";
        }
    }
}
