package net.fullstack.api.service;

import net.fullstack.api.dto.BbsDTO;
import net.fullstack.api.dto.PageRequestDTO;
import net.fullstack.api.dto.PageResponseDTO;
import org.springframework.data.domain.Page;

import java.util.List;

public interface BbsServiceIf {
    long countAll();

    List<BbsDTO> findAll(int page_no, int page_size);

    Page<BbsDTO> findAll(PageRequestDTO pageRequestDTO);

    PageResponseDTO<BbsDTO> findAllWithSearch(PageRequestDTO pageRequestDTO);

    BbsDTO findById(long id);

    long save(BbsDTO dto);

    long update(BbsDTO dto);

    void deleteById(long id);
}
