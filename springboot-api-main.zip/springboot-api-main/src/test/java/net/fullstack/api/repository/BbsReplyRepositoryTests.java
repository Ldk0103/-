package net.fullstack.api.repository;

import lombok.extern.log4j.Log4j2;
import net.fullstack.api.domain.BbsEntity;
import net.fullstack.api.domain.BbsReplyEntity;
import net.fullstack.api.dto.BbsReplyDTO;
import net.fullstack.api.repository.bbs.BbsReplyRepository;
import org.junit.jupiter.api.Test;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Log4j2
@SpringBootTest
public class BbsReplyRepositoryTests {
    @Autowired
    private BbsReplyRepository bbsReplyRepository;
    @Autowired
    private ModelMapper modelMapper;

    @Test
    public void testBbsReplyRegist() {
        BbsEntity board = BbsEntity.builder()
                .idx(1)
                .build();
        IntStream.rangeClosed(1, 10).forEach(
                i -> {
                    BbsReplyEntity bbsReplyEntity= BbsReplyEntity.builder()
                            .board(board)
                            .reply_user_id("user" + i)
                            .reply_title("댓글 테스트 제목 " + i)
                            .reply_content("댓글 테스트 내용 " + i)
                            .reg_date(LocalDateTime.now())
                            .reply_date(LocalDateTime.now())
                            .build();
                    BbsReplyEntity result = bbsReplyRepository.save(bbsReplyEntity);
                    log.info("result: {}", result);
                }
        );
    }




}
