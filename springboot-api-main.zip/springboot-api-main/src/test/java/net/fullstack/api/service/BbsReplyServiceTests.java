package net.fullstack.api.service;

import lombok.extern.log4j.Log4j2;
import net.fullstack.api.domain.BbsReplyEntity;
import net.fullstack.api.dto.BbsDTO;
import net.fullstack.api.dto.BbsReplyDTO;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Log4j2
@SpringBootTest
public class BbsReplyServiceTests {

    @Autowired
    private BbsReplyServiceIf bbsReplyService;

    @Test
    public void testReplyRegist() {

        log.info("==========================================");
        BbsReplyDTO bbsReplyDTO = BbsReplyDTO.builder()
                .board_idx(2)
                .reply_title("댓글 테스트 제목")
                .reply_content("댓글 테스트 내용")
                .reply_user_id("user1")
                .reply_date(LocalDateTime.now())
                .build();
        long idx = bbsReplyService.bbsReplyRegist(bbsReplyDTO);
        log.info("idx: {} ", idx);
        log.info("==========================================");
    }
    @Test
    public void testBbsReplyList() {
        log.info("========================");
        log.info("BbsReplyServiceImplTests >> testBbsReplyList >> replyDTOList");
        long bbs_idx = 1L;
        Pageable pageable = PageRequest.of(0, 10, Sort.by("idx").descending());
        List<BbsReplyDTO> bbsReplyDTOList = bbsReplyService.bbsReplyList(bbs_idx, pageable);
        bbsReplyDTOList.forEach(log::info);
        log.info("========================");
    }
    @Test
    public void testBbsReplyView() {
        log.info("========================");
        log.info("BbsReplyServiceImplTests >> testBbsReplyView ");
        long idx = 1L;
        BbsReplyDTO bbsReplyDTO = bbsReplyService.bbsReplyView(idx);
        log.info("bbsReplyDTO: {}", bbsReplyDTO);

    }

    @Test
    public void testBbsReplyModify() {
        bbsReplyService.bbsReplyModify(BbsReplyDTO.builder().idx(13).reply_title("수정").reply_content("서비스 게시판 제목 댓글 수정").build());
    }
    @Test
    public void testBbsReplyDelete() {
        Long idx = 1L;
        bbsReplyService.bbsReplyDelete(idx);
    }

}
